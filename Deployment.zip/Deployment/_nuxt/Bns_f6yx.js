import"./CXyoKjyT.js";const e=""+new URL("restore-image.CV_UoAEi.svg",import.meta.url).href;export{e as _};
