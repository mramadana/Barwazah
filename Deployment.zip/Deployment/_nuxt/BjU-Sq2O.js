import{aE as r}from"./CoG2HLAM.js";var e=r();export{e as O};
