import"./D7HON4Zz.js";const r=""+new URL("salla.C16TzIgG.svg",import.meta.url).href,s=""+new URL("zid.BK9IXTdt.svg",import.meta.url).href;export{r as _,s as a};
