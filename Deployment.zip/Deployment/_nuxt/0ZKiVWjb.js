import"./Dz4sT9z-.js";const e=""+new URL("restore-image.CV_UoAEi.svg",import.meta.url).href;export{e as _};
