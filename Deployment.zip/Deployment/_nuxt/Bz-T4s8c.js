import"./5Np3j6Vc.js";const e=""+new URL("restore-image.CV_UoAEi.svg",import.meta.url).href;export{e as _};
