import"./D7HON4Zz.js";const r=""+new URL("Logo.Dbb71-BG.svg",import.meta.url).href;export{r as _};
