import{_ as t,o,c as r,ab as c}from"./CoG2HLAM.js";const n={};function s(e,a){return o(),r("div",null,[c(e.$slots,"default")])}const _=t(n,[["render",s]]);export{_ as default};
