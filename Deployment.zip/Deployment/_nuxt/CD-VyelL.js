import"./uThEF0pG.js";const e=""+new URL("Rectangle.B0Gll4_9.svg",import.meta.url).href;export{e as _};
